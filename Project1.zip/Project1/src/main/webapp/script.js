/**
 * 
 */

let cart = JSON.parse(localStorage.getItem("cart")) || [];

document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".add-cart-btn").forEach(button => {
        button.addEventListener("click", (event) => {
            const showcase = event.target.closest(".showcase");
            const title = showcase.querySelector(".showcase-title").innerText;
            const price = showcase.querySelector(".price").innerText;
            const imgSrc = showcase.querySelector(".showcase-img").src;

            addToCart(title, price, imgSrc);
        });
    });
    
    displayCart();
});

function addToCart(name, price, image) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let existingItem = cart.find(item => item.name === name);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ name, price: parseFloat(price.replace(/[^\d.]/g, "")), image, quantity: 1 });
    }
    localStorage.setItem("cart", JSON.stringify(cart));
}




function displayCart() {
    const cartContainer = document.querySelector(".cart-container");
    cartContainer.innerHTML = "";
    
    cart.forEach((item, index) => {
        const cartItem = document.createElement("div");
        cartItem.classList.add("cart-item");
        cartItem.innerHTML = `
            <img src="${item.imgSrc}" width="50" alt="${item.title}">
            <p>${item.title}</p>
            <p>${item.price}</p>
            <input type="number" value="${item.quantity}" min="1" data-index="${index}" class="quantity-input">
            <button class="remove-btn" data-index="${index}">Remove</button>
        `;
        cartContainer.appendChild(cartItem);
    });

    document.querySelectorAll(".quantity-input").forEach(input => {
        input.addEventListener("change", (event) => {
            let index = event.target.dataset.index;
            cart[index].quantity = parseInt(event.target.value);
            localStorage.setItem("cart", JSON.stringify(cart));
        });
    });

    document.querySelectorAll(".remove-btn").forEach(button => {
        button.addEventListener("click", (event) => {
            let index = event.target.dataset.index;
            cart.splice(index, 1);
            localStorage.setItem("cart", JSON.stringify(cart));
            displayCart();
        });
    });
}

